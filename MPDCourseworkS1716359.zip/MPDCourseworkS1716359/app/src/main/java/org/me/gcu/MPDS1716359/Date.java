package org.me.gcu.MPDS1716359;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Pair;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

//Name: Euan Logan
//Matriculation Number: S1716359
public class Date extends AppCompatActivity {

    private Button datePicker;

    private TextView dateText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date);

        datePicker = findViewById(R.id.date_picker);
        dateText = findViewById(R.id.selected_date);

        MaterialDatePicker.Builder<Pair<Long, Long>> builder = MaterialDatePicker.Builder.dateRangePicker();
        builder.setTitleText("Please Select a Date");
        final MaterialDatePicker materialDatePicker = builder.build();

        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                materialDatePicker.show(getSupportFragmentManager(), "Date_Picker");

            }
        });

        materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
            @Override
            public void onPositiveButtonClick(Object selection) {
                dateText.setText("Selected Date : " + materialDatePicker.getHeaderText());
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.list:
                openEarthquakeList();
                Log.e("MyTag", "list selected");
                return true;
            case R.id.colour:
                Toast.makeText(this, "Color Coding Selected", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "colour selected");
                openColourCoding();
                return true;
            case R.id.date:
                Toast.makeText(this, "Date Range", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Date selected");
                openDate();
                return true;
            case R.id.map:
                Toast.makeText(this, "Earthquake Map", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Map Selected");
                openMap();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void openEarthquakeList(){
        Intent intent = new Intent(this, EarthquakeList.class);
        startActivity(intent);
    }

    public void openColourCoding(){
        Intent intent = new Intent(this, ColourCoding.class);
        startActivity(intent);
    }

    public void openDate(){
        Intent intent = new Intent(this, Date.class);
        startActivity(intent);
    }
    public void openMap() {
        Intent intent = new Intent(this, Map.class);
        startActivity(intent);
    }
}