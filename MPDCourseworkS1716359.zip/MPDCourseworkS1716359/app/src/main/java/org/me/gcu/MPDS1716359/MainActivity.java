package org.me.gcu.MPDS1716359;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
//Name: Euan Logan
//Matriculation Number: S1716359
public class MainActivity extends AppCompatActivity implements OnClickListener
{
    private String result = "";
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.e("MyTag","in onCreate");;
        startProgress();
        // More Code goes here
    }


    public void onClick(View aview)
    {
        Log.e("MyTag","in onClick");

        Log.e("MyTag","after startProgress");
    }

    public void startProgress()
    {
        // Run network access on a separate thread;
        new Thread(new Task(urlSource)).start();
    } //

    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    private class Task implements Runnable
    {
        private String url;

        public Task(String aurl)
        {
            url = aurl;
        }
        @Override
        public void run()
        {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag","in run");

            try
            {
                Log.e("MyTag","in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                Log.e("MyTag","after ready");
                //
                // Now read the data. Make sure that there are no specific hedrs
                // in the data file that you need to ignore.
                // The useful data that you need is in each of the item entries
                //
                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;


                }
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception in run");
            }



            //creates new earthquake class
            LinkedList <EarthquakeClass> alist = null;
            //calls method to parse data from url
            alist = parseData(result);

            // Write list to Log for testing
            if (alist != null)
            {
                Log.e("MyTag","List not null");
                for (Object o : alist)
                {
                    Log.e("MyTag",o.toString());
                }
            }
            else
            {
                Log.e("MyTag","List is null");
            }
            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !

            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                    //rawDataDisplay.setText(result);
                }
            });
        }

    }


    private LinkedList<EarthquakeClass> parseData(String dataToParse)
    {
        EarthquakeClass earthquake = null;
        LinkedList <EarthquakeClass> alist = null;
        try
        {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput( new StringReader( dataToParse ) );
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT)
            {
                // Found a start tag
                if(eventType == XmlPullParser.START_TAG)
                {
                    // Check which Tag we have
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        //creates new linked list
                        alist  = new LinkedList<EarthquakeClass>();
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        Log.e("MyTag","Item Start Tag found");
                        //creates new item to be stored in class
                        earthquake = new EarthquakeClass();
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("description"))
                    {
                        // Now just get the associated text
                        String temp = xpp.nextText();
                        //splitting description to assign location magnitude and depth variable
                        String[] arrOfStr = temp.split(";");
                        for (String a: arrOfStr) {
                            //further splits through a semi colon
                            String[] tmpStr = a.split(":");
                            switch (tmpStr[0].trim()) {
                                //looks for location and assigns location variable
                                case "Location":
                                    String loc = tmpStr[1].trim();
                                    earthquake.setLocation(loc);
                                    Log.e("MyTag", "Location is " + loc);
                                    break;
                                //looks for depth and assigns depth variable
                                case "Depth":
                                    //further splits whitespace so we only extract the depth value and not km string
                                    String[] depthStr = tmpStr[1].trim().split(" ");
                                    String depth = depthStr[0].trim();
                                    float d = Float.parseFloat(depth);
                                    earthquake.setDepth(d);
                                    Log.e("MyTag", "Depth is " + d);
                                    break;
                                //looks for magnitude and assigns magnitude variable
                                case "Magnitude":
                                    String mag = tmpStr[1].trim();
                                    float m = Float.parseFloat(mag);
                                    earthquake.setMagnitude(m);
                                    Log.e("MyTag", "Magnitude is " + m);
                                    break;
                            }
                        }
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("pubDate"))
                    {
                        // Now just get the associated text
                        String temp = xpp.nextText();
                        // prints to log for testing
                        Log.e("MyTag","Origin date is  " + temp);
                        earthquake.setOriginDateTime(temp);
                    }
                    else
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("category"))
                        {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // prints to log for testing
                            Log.e("MyTag","Category is " + temp);
                            earthquake.setCategory(temp);
                        }
                    else
                        // Check which Tag we have
                    if (xpp.getName().equalsIgnoreCase("lat"))
                    {
                            // Now just get the associated text
                            float temp = Float.parseFloat(xpp.nextText());
                            // prints to log for testing
                            Log.e("MyTag","Latitude is " + temp);
                            earthquake.setLatitude(temp);
                    }
                    else
                            // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("long"))
                        {
                            // Now just get the associated text
                            float temp = Float.parseFloat(xpp.nextText());
                            // prints to log for testing
                            Log.e("MyTag","Longitude is " + temp);
                            earthquake.setLongitude(temp);
                        }
                }
                else
                if(eventType == XmlPullParser.END_TAG)
                {
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        Log.e("MyTag","earthquake is " + earthquake.toString());
                        alist.add(earthquake);
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        int size;
                        size = alist.size();
                        Log.e("MyTag","channel size is " + size);
                    }
                }


                // Get the next event
                eventType = xpp.next();

            } // End of while


        }
        catch (XmlPullParserException ae1)
        {
            Log.e("MyTag","Parsing error" + ae1.toString());
        }
        catch (IOException ae1)
        {
            Log.e("MyTag","IO error during parsing");
        }

        Log.e("MyTag","End document");

        return alist;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.list:
                openEarthquakeList();
                Log.e("MyTag", "list selected");
                return true;
            case R.id.colour:
                Toast.makeText(this, "Color Coding Selected", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "colour selected");
                openColourCoding();
                return true;
            case R.id.date:
                Toast.makeText(this, "Date Range", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Date selected");
                openDate();
                return true;
            case R.id.map:
                Toast.makeText(this, "Earthquake Map", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Map Selected");
                openMap();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void openEarthquakeList(){
        Intent intent = new Intent(this, EarthquakeList.class);
        startActivity(intent);
    }

    public void openColourCoding(){
        Intent intent = new Intent(this, ColourCoding.class);
        startActivity(intent);
    }

    public void openDate(){
        Intent intent = new Intent(this, Date.class);
        startActivity(intent);
    }
    public void openMap() {
        Intent intent = new Intent(this, Map.class);
        startActivity(intent);
    }
}

