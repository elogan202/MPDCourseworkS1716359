package org.me.gcu.MPDS1716359;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
//Name: Euan Logan
//Matriculation Number: S1716359
public class Map extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.list:
                openEarthquakeList();
                Log.e("MyTag", "list selected");
                return true;
            case R.id.colour:
                Toast.makeText(this, "Color Coding Selected", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "colour selected");
                openColourCoding();
                return true;
            case R.id.date:
                Toast.makeText(this, "Date Range", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Date selected");
                openDate();
                return true;
            case R.id.map:
                Toast.makeText(this, "Earthquake Map", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Map Selected");
                openMap();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void openEarthquakeList(){
        Intent intent = new Intent(this, EarthquakeList.class);
        startActivity(intent);
    }

    public void openColourCoding(){
        Intent intent = new Intent(this, ColourCoding.class);
        startActivity(intent);
    }

    public void openDate(){
        Intent intent = new Intent(this, Date.class);
        startActivity(intent);
    }
    public void openMap() {
        Intent intent = new Intent(this, Map.class);
        startActivity(intent);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        LatLng Bute = new LatLng(56.389, -5.544);
        map.addMarker(new MarkerOptions().position(Bute).title("Location is Kerrera,Argyll and Bute"));
        map.moveCamera(CameraUpdateFactory.newLatLng(Bute));
    }
}






















