package org.me.gcu.MPDS1716359;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;
//Name: Euan Logan
//Matriculation Number: S1716359
public class EarthquakeList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earthquake_list);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.list:
                openEarthquakeList();
                Log.e("MyTag", "list selected");
                return true;
            case R.id.colour:
                Toast.makeText(this, "Color Coding Selected", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "colour selected");
                openColourCoding();
                return true;
            case R.id.date:
                Toast.makeText(this, "Date Range", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Date selected");
                openDate();
                return true;
            case R.id.map:
                Toast.makeText(this, "Earthquake Map", Toast.LENGTH_SHORT).show();
                Log.e("MyTag", "Map Selected");
                openMap();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void openEarthquakeList(){
        Intent intent = new Intent(this, EarthquakeList.class);
        startActivity(intent);
    }

    public void openColourCoding(){
        Intent intent = new Intent(this, ColourCoding.class);
        startActivity(intent);
    }

    public void openDate(){
        Intent intent = new Intent(this, Date.class);
        startActivity(intent);
    }

    public void openMap() {
        Intent intent = new Intent(this, Map.class);
        startActivity(intent);
    }

}