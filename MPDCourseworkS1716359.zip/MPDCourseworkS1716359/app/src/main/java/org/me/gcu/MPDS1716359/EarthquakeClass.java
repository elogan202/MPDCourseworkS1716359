package org.me.gcu.MPDS1716359;

//Name: Euan Logan
//Matriculation Number: S1716359

public class EarthquakeClass {
    private float magnitude;
    private float depth;
    private String originDateTime;
    private String location;
    private  String category;
    private float latitude;
    private float longitude;

    private String nut;

    public EarthquakeClass()
    {
        magnitude = 0;
        depth = 0;
        originDateTime = "";
        location = "";
        category = "";
        latitude = 0;
        longitude = 0;
    }

    public EarthquakeClass(float aMagnitude,float aDepth,String aOriginDateTime,String aLocation, String aCategory, float aLatitude, float aLongitude)
    {
        magnitude = aMagnitude;
        depth = aDepth;
        originDateTime= aOriginDateTime;
        location = aLocation;
        category = aCategory;
        latitude = aLatitude;
        longitude = aLongitude;
    }

    public float getMagnitude()
    {
        return magnitude;
    }

    public void setMagnitude(float aMagnitude) { magnitude = aMagnitude;}

    public float getDepth()
    {
        return depth;
    }

    public void setDepth(float aDepth) { depth = aDepth;}

    public String getOriginDateTime()
    {
        return originDateTime;
    }

    public void setOriginDateTime(String aOriginDateTime) {originDateTime = aOriginDateTime;}

    public String getLocation()
    {
        return location;
    }

    public void setLocation(String aLocation) {location = aLocation;}

    public String getCategory()
    {
        return category;
    }

    public void setCategory(String aCategory) {category = aCategory;}

    public float getLatitude()
    {
        return latitude;
    }

    public void setLatitude(float aLatitude) { latitude = aLatitude;}

    public float getLongitude()
    {
        return longitude;
    }

    public void setLongitude(float aLongitude) { longitude = aLongitude;}

    public String toString()
    {
        String temp;

        temp = location + " " + magnitude + " " + originDateTime + " " + depth + " " + latitude + " " + longitude;

        return temp;
    }

} // End of class